<?php
	$conn = new PDO( 'sql205.alojamento-gratis.com;dbname=ljmn_38672856_agendacontatos_2i', 'ljmn_38672856', '6342074260234G3');
	if(!$conn){
		die("Erro: Sem ligação à base de dados!");
	}
?>